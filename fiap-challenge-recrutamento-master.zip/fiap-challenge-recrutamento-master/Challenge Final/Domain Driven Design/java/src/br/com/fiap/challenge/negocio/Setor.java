package br.com.fiap.challenge.negocio;

public enum Setor {
    RECURSOSHUMANOS,
    TECNOLOGIA,
    MARKETING,
    FINANCEIRO
}
