package br.com.fiap.challenge.aplicacao;
import java.sql.Date;

import br.com.fiap.challenge.negocio.Candidato;
import br.com.fiap.challenge.negocio.Etapa;
import br.com.fiap.challenge.negocio.Senioridade;
import br.com.fiap.challenge.negocio.Setor;
import br.com.fiap.challenge.negocio.Vaga;

public class App {
    public App() {
        
    }
    public static void main(String[] args) throws Exception {
        Vaga vaga = new Vaga();
        vaga.setCandidatos(new Candidato[]{
            new Candidato(),
            new Candidato(),
            new Candidato()
        });
        vaga.setData(new Date(2019, 10, 20));
        vaga.setDescricao("Descricao");
        vaga.setEtapas(new Etapa[] {
            new Etapa(),
            new Etapa(),
            new Etapa()
        });
        vaga.setLink("link");
        vaga.setNome("nome");
        vaga.setSenioridade(Senioridade.ESTAGIO);
        vaga.setSetor(Setor.TECNOLOGIA);
        Candidato candidato = vaga.getCandidatos()[0];
        candidato.setCpf("16436435093l");
        candidato.setEmail("blablabla@gmail.com");
        candidato.setNome("Joao");
        candidato.setSenha("1234567");
        System.out.println("Cpf : "+candidato.getCpf()+"\n Email : "+candidato.getEmail()+"\n Nome : "+ candidato.getNome()+"\n Senha : "+ candidato.getSenha());
        Etapa etapa = vaga.getEtapas()[0];
        etapa.setDescricao("Descricao");
        etapa.setLink("Link");
        etapa.setNome("Etapa 1");
        System.out.println("Etapa : "+etapa.getDescricao()+"\n Link : "+etapa.getLink()+"\n Nome : "+etapa.getNome());
        System.out.println("Descricao : "+vaga.getDescricao()+"\n Link : "+vaga.getLink()+"\n Nome : "+vaga.getNome());
    }
}
