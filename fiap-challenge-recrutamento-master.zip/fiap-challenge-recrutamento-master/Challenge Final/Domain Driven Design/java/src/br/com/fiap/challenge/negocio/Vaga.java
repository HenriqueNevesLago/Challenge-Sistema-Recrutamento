package br.com.fiap.challenge.negocio;
import java.sql.Date;
public class Vaga {
    private String nome;
    private Date data;
    private Setor setor;
    private Senioridade senioridade;
    private String descricao;
    private Candidato[] candidatos;
    private Etapa[] etapas;
    private String link;
    public Vaga(){
        this.nome = "";
        this.descricao = "";
        this.link = "";
    }
    public Vaga(String nome,
    Date data,
    Setor setor,
    Senioridade senioridade,
    String descricao,
    Candidato[] candidatos,
    Etapa[] etapas,
    String link)
    {
        this.nome = nome;
        this.data = data;
        this.setor = setor;
        this.senioridade = senioridade;
        this.descricao = descricao;
        this.candidatos =candidatos;
        this.etapas = etapas;
        this.link = link;
    }
    
    public String getDescricao() {
        return descricao;
    }
    public Candidato[] getCandidatos() {
        return candidatos;
    }
    public Date getData() {
        return data;
    }
    public Etapa[] getEtapas() {
        return etapas;
    }
    public String getLink() {
        return link;
    }
    public String getNome() {
        return nome;
    }
    public Senioridade getSenioridade() {
        return senioridade;
    }
    public Setor getSetor() {
        return setor;
    }
    public void setCandidatos(Candidato[] candidatos) {
        this.candidatos = candidatos;
    }
    public void setData(Date data) {
        this.data = data;
    }
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    public void setEtapas(Etapa[] etapas) {
        this.etapas = etapas;
    }
    public void setLink(String link) {
        this.link = link;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public void setSenioridade(Senioridade senioridade) {
        this.senioridade = senioridade;
    }
    public void setSetor(Setor setor) {
        this.setor = setor;
    }
}
