package br.com.fiap.challenge.negocio;
public class Candidato {
    private String nome;
    private String cpf;
    private String senha;
    private String email;
    
    public Candidato() {
      this.nome = "";
      this.cpf = "";
      this.senha = "";
      this.email = "";
    }
    public Candidato(String nome, String cpf, String senha,String email){
        this.cpf = cpf;
        this.senha = senha;
        this.email = email;
    }
    public String getCpf() {
        return cpf;
    }
    public String getEmail() {
        return email;
    }
    public String getNome() {
        return nome;
    }
    public String getSenha() {
        return senha;
    }
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}
