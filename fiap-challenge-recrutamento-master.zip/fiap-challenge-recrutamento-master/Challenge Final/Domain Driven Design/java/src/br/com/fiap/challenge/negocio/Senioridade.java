package br.com.fiap.challenge.negocio;

public enum Senioridade {
	ESTAGIO,
    JUNIOR,
    PLENO,
    SENIOR,
    TRAINEE
}
