package br.com.fiap.challenge.negocio;
public class Etapa {
    private String nome;
    private String descricao;
    private String link;

    public Etapa(){
        this.nome = "";
        this.descricao= "";
        this.link = "";
    }
    public Etapa(String nome, String descricao, String link) {
        this.nome = nome;
        this.descricao = descricao;
        this.link = link;
    }

    public String getDescricao() {
        return descricao;
    }
    public String getLink() {
        return link;
    }
    public String getNome() {
        return nome;
    }
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    public void setLink(String link) {
        this.link = link;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
}
